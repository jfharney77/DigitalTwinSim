---
name: dell-clean-design
description: Apply Dell-support-inspired clean styling (no eyebrow text, no step numbering, no divider lines, no highlighted text, no serif fonts) plus anti-slop rules for UI copy and prose, to any web UI or mockup work.
---

# Dell Clean Design

Apply this skill when building or restyling web pages, mockups, or UI components for a project that follows the Dell-support visual language, and when writing any user-facing copy for them.

Reference screenshots (the source of truth for the look):
- `references/DellSupportSiteUS.png` — US support home (light). **Default variant.**
- `references/DellSupportSiteUK.png` — UK support home (dark navy hero). Use only if the user asks for the dark variant.

## Hard constraints — never violate

1. **No eyebrow text.** No small uppercase kicker/label lines above headings. A section gets one heading, nothing above it.
2. **No step numbering.** Wizard steps, lists of phases, and progress indicators show titles only — never "1.", "Step 2 of 5", numbered circles, or ordinal badges.
3. **No divider lines.** No `<hr>`, no decorative horizontal rules, no border-top/border-bottom used purely as a separator between sections. Separate content with whitespace and background changes instead. (Functional borders on cards, inputs, tiles, and the masthead bottom edge are fine — they outline a component, they don't divide prose.)
4. **No highlighted text.** No `<mark>`, no background-color spans behind words, no text highlighting for emphasis. Emphasis comes from weight and the Dell blue, sparingly. (A light-blue *component fill* like a selected tile is part of the Dell language and is allowed — the ban is on highlighted runs of text.)
5. **No serif fonts anywhere.** Every element — headings, body, buttons, inputs, textareas, code samples — uses the sans stack below. Check textareas and placeholder text explicitly; they often fall back to browser defaults.

## Dell visual language

### Typography
- Stack: `"Roboto","Helvetica Neue",Arial,sans-serif` (load Roboto 300/400/500/700 from Google Fonts when external requests are allowed; otherwise rely on the fallbacks).
- Page title: large and light — ~40px, weight 300.
- Section/step titles: ~28px, weight 400.
- Body: 14–16px, weight 400, line-height ~1.5. Muted text is a color change, not a size collapse.
- Bold (700) is reserved for buttons, active states, and key labels.

### Color tokens
| Token | Value | Use |
|---|---|---|
| Dell blue | `#0672CB` | Primary buttons, links, active borders/text, logo |
| Blue hover | `#0059A8` | Primary button hover |
| Blue tint | `#EBF5FC` | Selected/done tile fill, secondary button hover |
| Text | `#161616` | Default text |
| Muted | `#636363` | Secondary text |
| Border | `#D2D2D2` | Card, input, and tile borders |
| Page gray | `#F5F6F7` | Page background behind white cards |
| Error red | `#CE1126` | Validation/error text |
| Navy (UK variant only) | `#0F2A3F` | Dark hero band background |

### Structure (US/light variant — default)
- **Masthead**: white bar, 1px `#D2D2D2` bottom border, ~56px tall. Left: Dell-blue bold wordmark + slim nav (`Products  Solutions  Services  Support`, active item blue/bold). Right: muted utility text (e.g. Sign In).
- **Hero band**: white, full-width, holding the big light headline and a one-line muted subtitle. No imagery required.
- **Content**: on `#F5F6F7` page gray; white cards with 1px `#D2D2D2` borders, 4px radius, generous padding (32–40px).
- **UK/dark variant**: same masthead; hero band becomes navy with white light-weight headline; content below returns to the light gray scheme.

### Components
- **Buttons**: 2px radius, 14px/700. Primary: blue fill, white text. Secondary: white fill, blue text, blue border. Hover states always defined.
- **Inputs/textareas**: 1px `#D2D2D2` border, 2px radius, 10–12px padding; focus swaps border to Dell blue, no glow/shadow.
- **Step/option tiles**: equal-width white tiles, 1px border, 2px radius; active = blue border + blue text; done = blue border + `#EBF5FC` fill + check glyph (✓), never a number.
- **Cards**: white, 1px border, 4px radius. No drop shadows.

## Anti-slop rules (from gauravtiwari.org/stop-slop-ai-slop)

If the `stop-slop` skill is available, invoke it for any substantial prose. Regardless, enforce the following on everything you write for the project — UI copy, headings, docs, commit messages, README text:

### UI copy
- Every message tells the user **what happened** and **what to do next**; cut everything else. ("We couldn't save your changes. Try again, or copy your work and refresh." — not "An unexpected error has occurred.")
- Button labels are plain verbs: "Add contract", "Search", "Remove" — never "Unlock", "Elevate", "Get started on your journey".
- No marketing filler in interfaces: ban "seamless", "robust", "leverage", "elevate", "unlock", "navigate", "transformative", "game-changer", "take it to the next level", "at the end of the day".

### Prose
- Cut throat-clearing openers ("Here's the thing:", "Let me be clear:") and emphasis adverbs ("Importantly,", "Crucially,").
- No binary-contrast constructions ("Not X. Because Y.") or dramatic fragmentation ("Three words. That's it.").
- No false comprehensiveness ("from X to Y", "whether A or B") — name the one case that matters.
- No significance inflation ("testament", "pivotal", "paradigm-shifting").
- No synonym cycling: pick one term for a thing and repeat it.
- Vary sentence length; if three consecutive sentences match, rewrite one.
- No generic optimistic closing paragraphs; end on something specific.
- Density test: prefer sentences with a verifiable number, name, or date over abstractions.

### Design anti-slop
- Subtract by default: question whether each element earns its place before adding another.
- If a design comes back loud (gradients, screaming CTAs, animation), reduce saturation, loosen spacing, drop font weight.
- Before shipping: check spacing consistency, alignment, matching border radii, hover states, and text overflow with long content.

## Delivery checklist

Before handing over any page or component:

- [ ] Zero eyebrow text, step numbers, divider lines, highlighted text, serif glyphs (inspect textareas and placeholders).
- [ ] Fonts, colors, radii, and button styles match the token tables above.
- [ ] Layout follows masthead → hero band → gray content area (or the requested variant).
- [ ] Every user-facing string passes the UI-copy rules; longer prose passes the prose rules.
- [ ] Compared against the reference screenshot for the chosen variant.
